The documentations is here: 
http://support.jegtheme.com/theme/jnews/

Our support forum is here:
http://support.jegtheme.com/forums/forum/jnews/